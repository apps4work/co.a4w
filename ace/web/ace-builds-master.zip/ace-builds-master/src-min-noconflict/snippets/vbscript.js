ace.define("ace/snippets/vbscript",["require","exports","module"],function(e,t,n){"use strict";t.snippetText="",t.scope="vbscript"});
                (function() {
                    ace.require(["ace/snippets/vbscript"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            